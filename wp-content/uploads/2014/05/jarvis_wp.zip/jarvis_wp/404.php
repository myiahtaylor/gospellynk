<?php get_header(); ?> 

<?php
   get_template_part('menu_section');  ?>




    <div class="section post-single"><!-- SECTION -->

      <div class="container">   
            <div class="row">        
                <div class="sixteen columns">                
                  <h1 class="aligncenter">404</p>
                  <h2 class="aligncenter">Page Not Found</h2>                  
                </div><!-- END SPAN8 -->
             </div>   
      </div>	
		

    </div><!--END SECTION -->





<?php get_footer(); ?>