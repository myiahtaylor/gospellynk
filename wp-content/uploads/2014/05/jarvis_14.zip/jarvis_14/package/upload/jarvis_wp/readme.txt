Jarvis WordPress Changelog

13th August 2013 - Version 1.0

	- Initial Release

15th Aug 2013 - Version 1.0.1

                - fixed metabox issue that appears after installation.
                - fixed google fonts issue in options panel.
                - fixed font-size issue in options panel..
                - fixed home logo bug in options panel..
               - fixed footer color setting bug in options panel..
                + Added new version of demo content data.


17th Aug 2013 - Version 1.1
                 - Fixed the Fatal Error/Admin crash bug on installation.
                 - Fixed the Page Title Disabling bug.
                 - Fixed the Home Logo Scroll Fix.
                 - Fixed the Blank White page issue on installation.



23th Aug 2013 - Version 1.2
                 + Added "back to top" button.
                 + Added Xing, Instagram social icons.
                 + Added Sub Title Typography options(Theme Options).
                 + Added Title Style Switching option(Theme Options).
                 - Fixed the Parallax issues for ipads.
                 - Fixed AJAX Portfolio issues while opening for the first time.
                 - Added Dark Skin.

                 
28th Sept 2013 - Version 1.3
                 + Added Angel List Social Icon. (Files to be changed - footer.php, function.options.php, social.css, Add angellist.png in images folder).
                 + Added New Video Background for home section that supports both vimeo and Youtube (Files to be changed - home_section.php, footer.php, functions.php, scripts.js).
                 + Added Target Blank for client shortcodes. (Files to be changed - shortcodes.php)


                 -Fixed Portfolio Half loading issue.  (Files to be changed - scripts.js)
                 -Fixed Navigation Hover, Active modes color issues.  (Files to be changed - custom-style.php )
                 -Fixed Home Text Slider loading issue. (Files to be changed - scripts.js)
                 -Team hover bug in separate pages, Team close button in mobile devices (Files to be changed - shortcodes.css)
                 -Fixed Tabs, Toggles and accordions loading inside portfolio ajax. (Files to be changed - shortcodes.js, scripts.js )
                 -Minor CSS, JS bugs fixed.
                 -Translation file updated.